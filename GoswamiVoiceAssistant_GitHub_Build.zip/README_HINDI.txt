GOSWAMI VOICE ASSISTANT — शुरुआती Android प्रोजेक्ट

फोन: Samsung Galaxy M21, Android 12+
इस शुरुआती संस्करण में:
- बटन दबाकर हिंदी वॉयस कमांड पहचानना
- हिंदी Text-to-Speech जवाब (फोन में हिंदी TTS आवाज उपलब्ध होनी चाहिए)
- समय बताना
- टॉर्च चालू/बंद
- मीडिया वॉल्यूम बढ़ाना/कम करना
- WhatsApp, कैमरा और Settings खोलना
- Device Admin अनुमति मिलने के बाद फोन लॉक करना
- कॉल कमांड पर सुरक्षित Dialer स्क्रीन खोलना (कॉल अपने-आप नहीं लगती)

महत्वपूर्ण सीमाएँ:
- यह अभी लगातार "हे गोस्वामी" सुनने वाला बैकग्राउंड wake-word सिस्टम नहीं है।
- Android 12 में लॉक स्क्रीन पर हमेशा माइक्रोफोन सुनते रहना भरोसेमंद/सामान्य ऐप के लिए सीमित है।
- हर ऐप/फोन फीचर को आवाज़ से कंट्रोल करने के लिए अलग अनुमति और Android API की जरूरत पड़ सकती है।
- ऑफलाइन पहचान फोन में उपलब्ध Speech Recognition सेवा और डाउनलोड की गई भाषा पर निर्भर करती है।
- किसी व्यक्ति को कॉल करने के लिए अभी फोन की डायल स्क्रीन खुलेगी; कॉल करने से पहले आप नंबर/नाम चुनेंगे।

बनाने के लिए:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Open चुनकर GoswamiVoiceAssistant फोल्डर खोलें।
4. Gradle Sync पूरा होने दें और Android SDK 35 इंस्टॉल करें।
5. Samsung M21 में Developer options और USB debugging चालू करके USB से जोड़ें।
6. Android Studio में Run दबाएँ।
7. APK के लिए Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।

यह प्रोजेक्ट source code है, पहले से बना APK नहीं।

मोबाइल से GitHub Actions द्वारा APK बनाना:
1. GitHub पर नया Public या Private repository बनाएँ, नाम GoswamiVoiceAssistant रखें।
2. ZIP को फोन में Extract करें।
3. GitHub repository में Add file > Upload files चुनें।
4. Extract किए गए फोल्डर के अंदर की सभी फाइलें/फोल्डर अपलोड करें। .github फोल्डर भी शामिल होना चाहिए।
5. Commit changes करें।
6. Actions टैब खोलें। "Build Goswami Voice Assistant APK" workflow चुनें।
7. Run workflow दबाएँ; build सफल होने पर नीचे Artifacts में APK ZIP मिलेगा।
