package com.goswami.voiceassistant;

import android.app.admin.DeviceAdminReceiver;

public class LockAdminReceiver extends DeviceAdminReceiver { }
