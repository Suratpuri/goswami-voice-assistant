package com.goswami.voiceassistant;

import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 10;
    private static final int REQ_ADMIN = 11;
    private TextView status;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean torchOn = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int lang = tts.setLanguage(new Locale("hi", "IN"));
                if (lang == TextToSpeech.LANG_MISSING_DATA ||
                    lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                    say("हिंदी आवाज़ उपलब्ध नहीं है। फोन की टेक्स्ट टू स्पीच सेटिंग में हिंदी आवाज़ डाउनलोड करें।");
                }
            }
        });

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        }
        setupRecognizer();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 48, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF4F6FA);

        TextView title = new TextView(this);
        title.setText("🎤  GOSWAMI");
        title.setTextSize(28);
        title.setTextColor(0xFF172554);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("VOICE ASSISTANT");
        subtitle.setTextSize(16);
        subtitle.setTextColor(0xFF475569);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        status = new TextView(this);
        status.setText("माइक दबाकर हिंदी में बोलें");
        status.setTextSize(18);
        status.setTextColor(0xFF0F172A);
        status.setGravity(Gravity.CENTER);
        status.setPadding(8, 40, 8, 30);
        root.addView(status);

        Button listen = new Button(this);
        listen.setText("🎙️  बोलने के लिए दबाएँ");
        listen.setTextSize(18);
        listen.setOnClickListener(v -> startListening());
        root.addView(listen);

        Button admin = new Button(this);
        admin.setText("फोन लॉक की अनुमति चालू करें");
        admin.setOnClickListener(v -> requestLockPermission());
        root.addView(admin);

        TextView help = new TextView(this);
        help.setText("\nउदाहरण:\n• समय बताओ\n• टॉर्च चालू / बंद करो\n• मम्मी को कॉल करो (नंबर डायल स्क्रीन खुलेगी)\n• WhatsApp खोलो\n• कैमरा खोलो\n• फोन लॉक करो");
        help.setTextSize(15);
        help.setTextColor(0xFF334155);
        root.addView(help);

        setContentView(root);
    }

    private void setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("इस फोन में वॉयस पहचान सेवा उपलब्ध नहीं है।");
            return;
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { status.setText("सुन रहा हूँ…"); }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { status.setText("समझ रहा हूँ…"); }
            @Override public void onError(int error) { status.setText("आवाज़ समझ नहीं आई। फिर से माइक दबाएँ।"); }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String command = matches.get(0);
                    status.setText("आपने कहा: " + command);
                    handleCommand(command.toLowerCase(new Locale("hi", "IN")));
                }
            }
            @Override public void onPartialResults(Bundle partialResults) { }
            @Override public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (recognizer == null) setupRecognizer();
        if (recognizer == null) return;
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "हे गोस्वामी, बोलिए");
        recognizer.startListening(intent);
    }

    private void handleCommand(String c) {
        if (c.contains("समय") || c.contains("टाइम")) {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("hh:mm a", new Locale("hi", "IN"));
            say("अभी समय है " + f.format(new java.util.Date()));
        } else if (c.contains("टॉर्च") && (c.contains("बंद") || c.contains("ऑफ"))) {
            setTorch(false);
        } else if (c.contains("टॉर्च") || c.contains("फ्लैश")) {
            setTorch(true);
        } else if (c.contains("वॉल्यूम") && (c.contains("बढ़ा") || c.contains("ज्यादा"))) {
            volume(AudioManager.ADJUST_RAISE);
        } else if (c.contains("वॉल्यूम") && (c.contains("कम") || c.contains("घटा"))) {
            volume(AudioManager.ADJUST_LOWER);
        } else if (c.contains("लॉक")) {
            lockPhone();
        } else if (c.contains("व्हाट्स") || c.contains("वॉट्स")) {
            openApp("com.whatsapp", "WhatsApp");
        } else if (c.contains("कैमरा")) {
            launch(new Intent("android.media.action.IMAGE_CAPTURE"));
        } else if (c.contains("कॉल") || c.contains("फोन करो")) {
            say("किसे कॉल करना है? अभी मैं डायल स्क्रीन खोल सकता हूँ।");
            Intent dial = new Intent(Intent.ACTION_DIAL);
            launch(dial);
        } else if (c.contains("सेटिंग")) {
            launch(new Intent(android.provider.Settings.ACTION_SETTINGS));
        } else {
            say("यह कमांड अभी उपलब्ध नहीं है।");
        }
    }

    private void setTorch(boolean on) {
        try {
            CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String[] ids = cm.getCameraIdList();
            if (ids.length == 0) { say("टॉर्च उपलब्ध नहीं है।"); return; }
            cm.setTorchMode(ids[0], on);
            torchOn = on;
            say(on ? "टॉर्च चालू कर दी" : "टॉर्च बंद कर दी");
        } catch (Exception e) { say("टॉर्च नहीं चला सकी।"); }
    }

    private void volume(int direction) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
        say(direction == AudioManager.ADJUST_RAISE ? "वॉल्यूम बढ़ा दिया" : "वॉल्यूम कम कर दिया");
    }

    private void requestLockPermission() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(this, LockAdminReceiver.class);
        if (!dpm.isAdminActive(admin)) {
            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "आवाज़ से फोन लॉक करने के लिए यह अनुमति चाहिए।");
            startActivityForResult(i, REQ_ADMIN);
        } else say("फोन लॉक की अनुमति पहले से चालू है।");
    }

    private void lockPhone() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(this, LockAdminReceiver.class);
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow();
        } else {
            say("पहले फोन लॉक की अनुमति चालू करें।");
            requestLockPermission();
        }
    }

    private void openApp(String pkg, String name) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) launch(i);
        else say(name + " फोन में इंस्टॉल नहीं है।");
    }

    private void launch(Intent i) {
        try { startActivity(i); }
        catch (Exception e) { say("यह सुविधा अभी नहीं खुल सकी।"); }
    }

    private void say(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "goswami");
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
